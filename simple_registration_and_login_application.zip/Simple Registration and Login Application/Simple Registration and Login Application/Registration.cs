﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Simple_Registration_and_Login_Application
{
    public partial class Registration : Form
    {
        SQLiteConnection conn;
        String connectString;

        public Registration()
        {
            InitializeComponent();
            connectString = @"Data Source=" + Application.StartupPath + @"\Database\login.db; version=3";
        }

        private void Register(object sender, EventArgs e) {
            using (conn = new SQLiteConnection(connectString)) { 
                try {
                    if (txt_username.Text != "" || txt_password.Text != "")
                    {
                        SQLiteCommand cmd = new SQLiteCommand();
                        cmd.CommandText = @"INSERT INTO member (firstname, lastname, username, password) VALUES(@firstname, @lastname, @username, @password)";
                        cmd.Connection = conn;
                        cmd.Parameters.Add(new SQLiteParameter("@firstname", txt_firstname.Text));
                        cmd.Parameters.Add(new SQLiteParameter("@lastname", txt_lastname.Text));
                        cmd.Parameters.Add(new SQLiteParameter("@username", txt_username.Text));
                        cmd.Parameters.Add(new SQLiteParameter("@password", txt_password.Text));

                        conn.Open();

                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                        {
                            MessageBox.Show("Successfully Created!");
                            txt_firstname.Text = "";
                            txt_lastname.Text = "";
                            txt_username.Text = "";
                            txt_password.Text = "";
                        }
                    }
                    else {
                        MessageBox.Show("Required Fields!");
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void GoToLogin(object sender, EventArgs e) {
            Login login = new Login();
            this.Close();
            login.Show();
        }

    }
}
