﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Simple_Registration_and_Login_Application
{
    public partial class Login : Form
    {

        SQLiteConnection conn;
        SQLiteCommand cmd;
        String connectString;
        SQLiteDataReader rd;
        public Login()
        {
            InitializeComponent();
            connectString = @"Data Source=" + Application.StartupPath + @"\Database\login.db;version=3";
        }
     

        private void LoginButton(object sender, EventArgs e) {
            if (txt_username.Text == "" || txt_password.Text == "") {
                MessageBox.Show("Required Fields!");
            }
            else { 
                using (conn = new SQLiteConnection(connectString))
                {
                    try
                    {
                        conn.Open();
                        string query = "SELECT * FROM member WHERE username='" + txt_username.Text + "' AND password='" + txt_password.Text + "'";
                        cmd = new SQLiteCommand(query, conn);
                        cmd.ExecuteNonQuery();
                        rd = cmd.ExecuteReader();

                        int row = 0;

                        while (rd.Read())
                        {
                            row++;
                        }

                        if (row == 1)
                        {
                            MessageBox.Show("Successfully Login");
                            Home home = new Home();
                            this.Hide();
                            home.Show();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void GoToRegister(object sender, EventArgs e) {
            Registration registration = new Registration();
            this.Hide();
            registration.Show();
        }

    }
 
}
